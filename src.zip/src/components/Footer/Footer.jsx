const Footer = () => (
  <footer style={{ color: '#888', padding: 40, textAlign: 'center', background: '#111' }}>
    © 2024 Netflix Clone. Được xây dựng với ❤️
  </footer>
);
