import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
  height: 85vh;
  background: linear-gradient(to top, #141414 10%, transparent 90%), 
              url('https://...poster.jpg') center/cover no-repeat;
  color: white;
  display: flex;
  align-items: end;
  padding: 60px 30px;
`;

const Hero = () => {
  return (
    <Container>
      <div>
        <h1>404 Chạy ngay đi</h1>
        <p>Thể loại: Kinh dị, Hành động</p>
        <button>Xem ngay</button>
      </div>
    </Container>
  );
};

export default Hero;
