import React from 'react';
import styled from 'styled-components';
import { FaBell, FaSearch } from 'react-icons/fa';

const Container = styled.div`
  position: fixed;
  top: 0;
  width: 100%;
  padding: 15px 30px;
  background: black;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  z-index: 999;
`;

const Logo = styled.h1`
  color: #e50914;
`;

const Menu = styled.div`
  display: flex;
  gap: 25px;
  font-weight: 500;
`;

const Right = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
`;

const Avatar = styled.img`
  width: 35px;
  height: 35px;
  border-radius: 5px;
`;

const Navbar = () => {
  return (
    <Container>
      <Logo>NETFLIX</Logo>
      <Menu>
        <span>Trang chủ</span>
        <span>Series</span>
        <span>Phim</span>
        <span>Mới & Phổ biến</span>
        <span>Danh sách của tôi</span>
      </Menu>
      <Right>
        <FaSearch />
        <FaBell />
        <Avatar src="https://i.pravatar.cc/150?img=12" />
      </Right>
    </Container>
  );
};

export default Navbar;
